# Security requirements

- Role must be enforced server-side, not only by UI.
- Use Firebase custom claims or a backend authorization layer.
- Validate every order total server-side.
- Generate order IDs transactionally.
- Verify payment provider webhooks.
- Make payment webhooks idempotent.
- Use conditional transaction for driver assignment.
- Restrict precise live location to authorized order participants/admins.
- Restrict receipt/delivery-proof storage paths.
- Log sensitive admin actions.
- Do not ship server secrets/payment secrets in APK.
