# End-to-end flow

Customer:
1. authenticated and verified
2. chooses merchant/menu
3. adds items to cart
4. selects address
5. backend calculates authoritative quote
6. payment created
7. order created with unique #Fxx
8. customer receives status notifications

Merchant:
1. receives new order
2. accepts/rejects
3. prepares
4. marks READY
5. backend triggers driver matching

Driver:
1. online and eligible
2. receives short-lived offer
3. first valid acceptance wins transaction
4. navigates to merchant
5. photographs receipt
6. confirms pickup
7. starts route
8. photographs proof of delivery
9. completes order

Admin:
- monitors users, merchants, drivers, orders, payments, locations and audit events.

Production architecture:
Flutter -> Firebase Auth/Firestore/Storage/FCM -> trusted backend/Cloud Functions -> payment provider/maps services.
