enum UserRole { customer, merchant, driver, admin }

enum OrderStatus {
  pending,
  accepted,
  preparing,
  ready,
  driverAssigned,
  pickedUp,
  onTheWay,
  delivered,
  cancelled,
}

class DemoOrder {
  String id;
  String customerName;
  String merchantName;
  String? driverName;
  int itemTotal;
  int deliveryFee;
  int serviceFee;
  OrderStatus status;
  bool receiptUploaded;
  bool deliveryProofUploaded;

  DemoOrder({
    required this.id,
    required this.customerName,
    required this.merchantName,
    required this.itemTotal,
    required this.deliveryFee,
    required this.serviceFee,
    this.driverName,
    this.status = OrderStatus.pending,
    this.receiptUploaded = false,
    this.deliveryProofUploaded = false,
  });

  int get customerTotal => itemTotal + deliveryFee + serviceFee;
}
