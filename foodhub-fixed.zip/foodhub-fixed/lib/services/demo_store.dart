import 'package:flutter/foundation.dart';
import '../models.dart';

class DemoStore extends ChangeNotifier {
  DemoStore._();
  static final DemoStore instance = DemoStore._();

  int _sequence = 1;
  final List<DemoOrder> orders = [];

  DemoOrder? get activeOrder => orders.isEmpty ? null : orders.first;

  DemoOrder createDemoOrder() {
    final order = DemoOrder(
      id: '#F${_sequence.toString().padLeft(2, '0')}',
      customerName: 'Customer Demo',
      merchantName: 'FoodHub Kitchen',
      itemTotal: 25000,
      deliveryFee: 10000,
      serviceFee: 2000,
    );
    _sequence++;
    orders.insert(0, order);
    notifyListeners();
    return order;
  }

  void merchantAccept() {
    activeOrder?.status = OrderStatus.accepted;
    notifyListeners();
  }

  void startPreparing() {
    activeOrder?.status = OrderStatus.preparing;
    notifyListeners();
  }

  void markReady() {
    activeOrder?.status = OrderStatus.ready;
    notifyListeners();
  }

  void assignDriver() {
    if (activeOrder == null) return;
    activeOrder!.driverName = 'Driver Demo';
    activeOrder!.status = OrderStatus.driverAssigned;
    notifyListeners();
  }

  void pickup() {
    final o = activeOrder;
    if (o == null) return;
    o.receiptUploaded = true;
    o.status = OrderStatus.pickedUp;
    notifyListeners();
  }

  void onTheWay() {
    activeOrder?.status = OrderStatus.onTheWay;
    notifyListeners();
  }

  void delivered() {
    final o = activeOrder;
    if (o == null) return;
    o.deliveryProofUploaded = true;
    o.status = OrderStatus.delivered;
    notifyListeners();
  }
}
