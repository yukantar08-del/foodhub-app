# FoodHub v0.6 — Integrated Single-App Prototype

One Flutter app with four role dashboards:
Customer, Merchant, Driver, Admin.

This version provides a coherent navigation shell and shared demo state:
- role dashboard
- customer checkout
- merchant order processing
- driver offer/delivery
- admin monitoring
- order status shared across screens in this prototype
- chat entry point
- payment entry point
- location/tracking entry point
- professional Material 3 UI foundation

The demo state is local/in-memory. For production, replace DemoStore with Firebase/secure backend services.
